package forca;

import java.util.Random;
import java.util.Scanner;

public class Forca {
    
    public static void main(String[] args) {     
        
        Scanner Leitor = new Scanner(System.in);
        Random Randomico = new Random();    
        String Npal[][] = new String[50][2];
        String Contcad;
        int i=0, Totpal = 20;               
        do 
        {
            System.out.println("Digite uma palavra nova: ");
            Npal[i][0] = Leitor.next();
            System.out.println("Digite uma dica para a palavra nova: ");
            Npal[i][1] = Leitor.next();
            Totpal++;
            i++;
            System.out.print("Deseja cadastrar uma nova palavra? s/n: ");
            Contcad = Leitor.next();
        } while ( i < Npal.length && Contcad.toLowerCase().substring(0,1).contains("s"));
        
                String Status="", Contjog, Tentletra, Erroslet="", Palut[]= new String[2],
               Palpront[][] = new String[][]
               {
               {"Abacate","Fruta"},
               {"Acerola","Fruta"},
               {"Banana","Fruta"},
               {"Caju","Fruta"},
               {"Damasco","Fruta"},
               {"Televisao","Eletrodomestico"},
               {"Computador","Eletrodomestico"},
               {"Liquidificador","Eletrodomestico"},
               {"Torradeira","Eletrodomestico"},
               {"Portugues","Disciplina"},
               {"Matematica","Disciplina"},
               {"Ingles","Disciplina"},
               {"Geografia","Disciplina"},
               {"Quimica","Disciplina"},
               {"Programacao","Disciplina"},
               {"Batman","Her?"},
               {"Hulk","Her?"},
               {"Robin","Her?"},
               {"Alessandro","Professor"},
               {"Norberto","Professor"}
        };
        int Vitorias=0, Derrotas=0, Acertos=0, Erros=0, Palsort=0;
        i = 0;
        do
        {
            Palsort = Randomico.nextInt(Totpal);
            if (Palsort > 19) {
                Palsort-=20;
                Palut[0] = Npal[Palsort][0];
                Palut[1] = Npal[Palsort][1];
            } else 
            {
                Palut[0] = Palpront[Palsort][0];
                Palut[1] = Palpront[Palsort][1];
            }
            String Acertoslet[] = new String[Palut[0].length()], Palsolet[] = new String[Palut[0].length()];

            for ( i = 0; i < Palsolet.length; i++)
            {
                Palsolet[i] = Palut[0].substring(i,i+1);
                Acertoslet[i] = "_";
            }

            do 
            {
                System.out.println("\n\nDica: "+Palut[1]);
                System.out.print("Palavra: ");
                for ( i = 0; i < Acertoslet.length; i++)
                {
                    System.out.print(Acertoslet[i]+" ");
                }
                System.out.println();
                System.out.println("Voce pussui "+(5-Erros)+" tentativas");
                
                if (Erroslet.length() > 0)
                {
                    System.out.println("Letras erradas: "+Erroslet);
                }
                
                System.out.print("Tentativa: ");
                Tentletra = Leitor.next().substring(0,1);
                for ( i = 0; i < Palsolet.length; i++)
                {
                    if ( Tentletra.contains(Palsolet[i].toLowerCase()))
                    {
                        Acertoslet[i] = Palsolet[i];
                        Status = "Acertou";
                        Acertos++;
                    }
                } 
                if (!Status.contains("Acertou"))
                {
                    Erros++;
                    Erroslet += Tentletra+" ";
                }
                Status = "";
            } while ( (Erros < 6) && (Acertos != Palsolet.length) );
            
            if ( Erros == 6 )
            {
                System.out.println("\nQue pena! Voc?perdeu o jogo!\nA palavra era: "+Palut[0]);
                Derrotas++;
            } else 
            {
                System.out.println("\nParab?s! Voc?ganhou o jogo!\nA palavra era: "+Palut[0]);
                Vitorias++;
            }
            
            System.out.print("Derrotas: " + Derrotas
                    + "\nVitorias: " + Vitorias
                    + "\nDeseja continuar jogando? s/n: ");
            Contjog = Leitor.next();
            
            Acertos=0;
            Erros=0;
        } while (Contjog.substring(0,1).contains("s"));
    }    
}
