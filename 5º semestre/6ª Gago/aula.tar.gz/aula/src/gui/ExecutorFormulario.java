package gui;

public class ExecutorFormulario {

	public static void main(String[] args) {
		Formulario f = new Formulario();
	}
	
}