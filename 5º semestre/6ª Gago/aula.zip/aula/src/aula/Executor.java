package aula;

public class Executor {
	
	public static void main(String args[]) {
		
		Pessoa p1 = new Pessoa("Jarbas", 28);
		p1.apresenteSe();
		
		Pessoa p2 = new Pessoa("Everton", 15);
		p2.apresenteSe();
		

	}
	
}
