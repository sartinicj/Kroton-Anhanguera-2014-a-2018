Lanchonete
==========

Regras
------

1. Refatorar só se os testes estiverem passando.
2. Ao sair, o piloto deve deixar o código compilando.

Mudanças
--------

1. Adicionar promoção "Seja Light" - se tiver alface e não tiver bacon, ganhe 10% de desconto.
2. Adicionar promoção "Muito Queijo" - se tiver duas porções de queijo, ganhe a terceira.
3. A promoção "Muito Queijo" deve ser prioritária em relação à "Seja Light"  
4. Inflação! Os ingredientes sofrem alteração de preços com frequência!