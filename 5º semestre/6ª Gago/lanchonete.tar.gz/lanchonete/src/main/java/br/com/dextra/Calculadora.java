package br.com.dextra;

public class Calculadora {

	public Integer somar(Integer a, Integer b) {
		return a + b;
	}
	
	public Integer subtrair(Integer c, Integer d){
		return c - d;
	}
	
}