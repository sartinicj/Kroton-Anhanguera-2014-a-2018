package br.com.dextra;

import java.util.ArrayList;
import java.util.List;

public class Lanche {

	private List<Ingrediente> ingredientes;

	private double preco = 0.0;

	public Lanche() {
		this.ingredientes = new ArrayList<Ingrediente>();
	}

	public Double preco() {
		for (Ingrediente ingrediente : this.ingredientes) {
			preco += ingrediente.preco();
		}
		Promocao p = FabricaPromocoes.obterPromocao(this);
		if (p != null) {
			preco = p.calcularPreco(this);
		}

		return preco;
	}

	public double getPreco() {
		return preco;
	}

	public List<Ingrediente> getIngredientes() {
		return ingredientes;
	}

	public void add(Ingrediente ingrediente) {
		this.ingredientes.add(ingrediente);
	}
}