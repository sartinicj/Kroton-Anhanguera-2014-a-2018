package br.com.dextra;

import java.util.Iterator;
import java.util.List;

public enum Ingrediente {
	
	HamburguerCarne {
		@Override
		public double preco() {
			return 1.3;
		}
	},
	HamburguerFrango {
		@Override
		public double preco() {
			return 1.2;
		}
	},
	Bacon {
		@Override
		public double preco() {
			return 1.0;
		}
	},
	Queijo {
		@Override
		public double preco() {
			return 0.8;
		}
	},
	Ovo {
		@Override
		public double preco() {
			return 0.5;
		}
	},
	Alface {
		@Override
		public double preco() {
			return 0.1;
		}
	};
	
	public int contar(List<Ingrediente> ingredientes) {
		int total = 0;
		for (Ingrediente ingrediente : ingredientes) {
			if (ingrediente.equals(this)) {
				total++;
			}
		}
		return total;
	}

	public abstract double preco();

}