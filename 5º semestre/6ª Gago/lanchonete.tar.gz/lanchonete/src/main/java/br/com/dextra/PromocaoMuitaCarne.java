package br.com.dextra;

import java.util.List;

public class PromocaoMuitaCarne implements Promocao{

	@Override
	public Double calcularPreco(Lanche lanche) {
		Double preco = lanche.getPreco();
		int nrCarne = Ingrediente.HamburguerCarne.contar(lanche.getIngredientes());
		int nrBacon = Ingrediente.Bacon.contar(lanche.getIngredientes());
		while (nrCarne >= 2) {
			nrCarne = nrCarne - 2;
			nrBacon = nrBacon - 1;
			preco = preco - Ingrediente.Bacon.preco();
		}
		return preco;
	}

	@Override
	public Boolean match(Lanche lanche) {
		List<Ingrediente> ingredientes = lanche.getIngredientes();
		return (Ingrediente.HamburguerCarne.contar(ingredientes ) >= 2
				&& Ingrediente.Bacon.contar(ingredientes) >= 1);
	}

}