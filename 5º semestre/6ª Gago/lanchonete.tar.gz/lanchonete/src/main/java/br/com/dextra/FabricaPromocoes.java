package br.com.dextra;

/**
 * Factory Pattern
 * @author everton.gago
 *
 */
public class FabricaPromocoes {

	public static Promocao obterPromocao(Lanche lanche) {
		// Strategy Pattern.
		Promocao listaPromocoes[] = {
			new PromocaoMuitoQueijo(),
			new PromocaoLight(),
			new PromocaoMuitaCarne()
		};
		
		for (Promocao p : listaPromocoes) {
			if (p.match(lanche))
				return p;
		}
		
		return null;
	}
	
}