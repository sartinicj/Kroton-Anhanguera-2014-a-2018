package br.com.dextra;

import java.util.List;

public class PromocaoMuitoQueijo implements Promocao {

	@Override
	public Double calcularPreco(Lanche lanche) {
		Double preco = lanche.getPreco();
		int nrQueijo = Ingrediente.Queijo.contar(lanche.getIngredientes());
		while (nrQueijo >= 2) {
			nrQueijo = nrQueijo - 2;
			preco = preco - Ingrediente.Queijo.preco();

		}
		return preco;
	}

	@Override
	public Boolean match(Lanche lanche) {
		List<Ingrediente> ingredientes = lanche.getIngredientes();
		return (Ingrediente.Queijo.contar(ingredientes ) >= 2);
	}

}