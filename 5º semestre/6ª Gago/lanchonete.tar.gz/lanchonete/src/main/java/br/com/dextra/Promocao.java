package br.com.dextra;

public interface Promocao {

	public Double calcularPreco(Lanche lanche);
	
	public Boolean match(Lanche lanche);
	
}