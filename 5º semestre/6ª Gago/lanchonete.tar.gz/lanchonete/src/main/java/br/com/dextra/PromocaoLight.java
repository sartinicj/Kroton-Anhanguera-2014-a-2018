package br.com.dextra;

import java.util.List;

public class PromocaoLight implements Promocao {

	@Override
	public Double calcularPreco(Lanche lanche) {
		Double preco = lanche.getPreco();
		preco = preco * 0.9d;
		return preco;
	}

	@Override
	public Boolean match(Lanche lanche) {
		List<Ingrediente> ingredientes = lanche.getIngredientes();
		return (Ingrediente.Alface.contar(ingredientes) > 0)
				&& (Ingrediente.Bacon.contar(ingredientes) < 1);
	}

}
