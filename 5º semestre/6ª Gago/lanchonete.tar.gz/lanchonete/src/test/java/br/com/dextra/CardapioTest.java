package br.com.dextra;

import org.junit.Assert;
import org.junit.Test;

public class CardapioTest {

	@Test
	public void testePreco() {
		Lanche lanche = new Lanche();
		lanche.add(Ingrediente.HamburguerCarne);
		lanche.add(Ingrediente.Queijo);
		lanche.add(Ingrediente.Bacon);
		lanche.add(Ingrediente.Ovo);
		Assert.assertEquals(new Double(3.6), lanche.preco());
	}

	@Test
	public void testPromocaoDuasCarnesGanhaBacon() {
		Lanche lanche = new Lanche();
		lanche.add(Ingrediente.Ovo);
		lanche.add(Ingrediente.HamburguerCarne);
		lanche.add(Ingrediente.HamburguerCarne);
		lanche.add(Ingrediente.Bacon);
		Assert.assertEquals(new Double(3.1), lanche.preco(), 0.01);
	}

	@Test
	public void testPromocaoTresCarnesGanhaBacon() {
		Lanche lanche = new Lanche();
		lanche.add(Ingrediente.Ovo);
		lanche.add(Ingrediente.HamburguerCarne);
		lanche.add(Ingrediente.HamburguerCarne);
		lanche.add(Ingrediente.HamburguerCarne);
		lanche.add(Ingrediente.Bacon);
		Assert.assertEquals(new Double(4.4), lanche.preco(), 0.01);
	}

	@Test
	public void testPromocaoDoisCarnesGanhaBacon2() {
		Lanche lanche = new Lanche();
		lanche.add(Ingrediente.Ovo);
		lanche.add(Ingrediente.HamburguerCarne);
		lanche.add(Ingrediente.HamburguerCarne);
		lanche.add(Ingrediente.Bacon);
		lanche.add(Ingrediente.Bacon);
		Assert.assertEquals(new Double(4.1), lanche.preco(), 0.01);
	}
	
	@Test
	public void testLight() {

		Lanche light = new Lanche();
		
		light.add(Ingrediente.HamburguerFrango);
		light.add(Ingrediente.Alface);
		light.add(Ingrediente.Queijo);
		Assert.assertEquals(new Double(2.1)*0.9d,light.preco(),0.01);
	}
	
	@Test
	public void testLight2() {

		Lanche light = new Lanche();
		
		light.add(Ingrediente.HamburguerCarne);
		light.add(Ingrediente.HamburguerCarne);
		light.add(Ingrediente.Alface);
		light.add(Ingrediente.Queijo);
		Assert.assertEquals(new Double(3.5)*0.9d,light.preco(),0.01);
	}
	
	@Test
	public void testmuitoqueijo(){
		Lanche Queijo = new Lanche ();
		Queijo.add(Ingrediente.Queijo);
		Queijo.add(Ingrediente.Queijo);
		Queijo.add(Ingrediente.Queijo);
		Queijo.add(Ingrediente.HamburguerCarne);
		Queijo.add(Ingrediente.Alface);
		Assert.assertEquals(new Double(3.0),Queijo.preco(),0.01);
	
	}
}


