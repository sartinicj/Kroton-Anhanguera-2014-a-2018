package br.com.dextra;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TesteCalculadora {

	Calculadora c;
	
	@Before
	public void iniciar() {
		c = new Calculadora();
	}
	
	@Test
	public void testeSomar() {
		Integer resultado = c.somar(10, 15);
		Integer esperado = 25;
		Assert.assertEquals(esperado, resultado);
	}
	
	@Test
	public void testeSubtrair(){
		Integer resultado = c.subtrair(30, 20);
		Integer esperado = 10;
		Assert.assertEquals(esperado, resultado);
	}
	
}