#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

typedef struct no
{
	int info;
	struct no* next;
} sNo;

typedef struct fila
{
	sNo* first;
	sNo* last;	
} sFila;

void criarFila(sFila* fila)
{
	fila->first = NULL;
	fila->last = NULL;
	printf("\nFila criada.");	
}

sNo* criarNo(int valor)
{
  sNo* p = (sNo*)malloc(sizeof(sNo));
  p->info = valor;
  p->next = NULL;
  return p;
}

int vazia(sFila* fila)
{
	return fila->first == NULL;	
}

void enqueue(sFila* fila, int valor)
{ 
  sNo* p = criarNo(valor); 
  if (vazia(fila)) fila->first = p;
  else fila->last->next = p;
  fila->last = p;    
  printf("\nValor inserido com sucesso: %d.", valor);
}

int dequeue(sFila* fila)
{
	sNo* p; int num;
	if (vazia(fila)){
	  printf("\nFila esta vazia.");	
	  return NULL;	
	} 
	p = fila->first;
	num = p->info;
	fila->first = p->next;
	if (fila->first == NULL) fila->last == NULL;
	free(p);
	return num;
}

void imprimir(sFila* fila)
{
	sNo* p; 
	if(vazia(fila)) 
	  printf ("\nFila esta vazia.");	
	else	
		for (p = fila->first; p != NULL; p = p->next) 
		  printf("\nInfo = %d", p->info);
}

void destruir(sFila* fila){
	sNo* p; sNo* d;
	if(!vazia(fila))	
	{	
		p = fila->first;
		while (p->next != NULL){ 
			d = p;
			p = p->next;
			free(d);
		}
		printf ("\nFila destruida.");
		criarFila(fila);	
    } else printf ("\nFila vazia.");
}


int main(int argc, char *argv[]) {
	int opcao, num; sFila fila; sFila* pfila = &fila; 
	do
	{
		printf("\n");
		printf("1 - Inicializar fila\n");	
		printf("2 - Enfileirar\n");
		printf("3 - Desenfileirar\n");
		printf("4 - Imprimir\n");
		printf("5 - Destruir\n");
		printf("0 - Sair\n");
		printf("\nEntre com a opcao: "); scanf("%d", &opcao); printf("\n");
		switch (opcao)
		{
			case 1: 
			    criarFila(pfila);
				break;
			case 2:
				printf ("\nEntre com o numero para enfileirar: "); scanf ("%d", &num); printf("\n");				
				enqueue(pfila, num);
				break;				
			case 3:	
				num = dequeue(pfila);
				if (num != NULL) printf("\nNumero desemfileirado %d.", num); printf("\n");
				break;
			case 4:		
				printf("\nImpressao da fila:");			
				imprimir(pfila);		
				break;
			case 5:	
				destruir(pfila);							
				break;
		}
		fflush(stdin);
	} while (opcao != 0);
	return 0;
}
