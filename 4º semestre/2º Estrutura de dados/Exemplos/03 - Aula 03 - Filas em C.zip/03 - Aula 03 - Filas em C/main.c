#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
#define MAX 5

typedef struct fila {	
	int primeiro;
	int ultimo;
	char vetor[MAX];
} sFila;

void criarFila(sFila* fila)
{
	fila->primeiro = 0;
	fila->ultimo = 0;	
	printf("\nFila criada com sucesso.");
}

int incr(int i)
{	
 return (i + 1) % MAX;
}

int vazia (sFila* fila)
{
  return (fila->primeiro == fila->ultimo);
}

void dequeue (sFila* fila)
{
 char valor;
 if (vazia(fila)) {
   printf("\nFila vazia.");   
 }
 else
 { 
   valor = fila->vetor[fila->primeiro];
   printf("\nItem removido %c na posicao %d.", valor);   
   fila->primeiro = incr(fila->primeiro);   
 }
}

void enqueue(sFila* fila, char valor)
{ 
  if (incr(fila->ultimo) == fila->primeiro)    
  	printf("\nFila cheia.");  
  else 
  {
    printf("\nInserido %c na posicao %d.", valor, fila->ultimo);
	fila->vetor[fila->ultimo] = valor;
 	fila->ultimo = incr(fila->ultimo);	 	
  } 
}

int main(int argc, char *argv[]) {
	sFila fila; char valor;	
	int opcao;
	do
	{
		printf("\n");	
		printf("1 - Criar fila\n");	
		printf("2 - Inserir\n");	
		printf("3 - Excluir\n");
		printf("0 - Sair\n");
		printf("Digite a opcao:"); scanf("%d", &opcao); 
		
		switch(opcao)
		{
			case 1: criarFila(&fila);
				break;
			case 2: 
				printf("\nInforme a letra: "); 
				scanf(" %c", &valor);
				enqueue(&fila, valor);
				break;
			case 3:
				dequeue(&fila);
				break;
			default:
				printf("\nOpcao invalida.");
				break;
		}
		
	} while(opcao != 0);
	printf("\nFim do Programa");
	return 0;
}
