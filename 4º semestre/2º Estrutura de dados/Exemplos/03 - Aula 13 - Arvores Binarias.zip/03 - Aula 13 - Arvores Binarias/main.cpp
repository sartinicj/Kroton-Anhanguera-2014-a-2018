#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
struct arvore
{
	int valor;
	struct arvore* esquerda;
	struct arvore* direita;
};

struct arvore* sarvore(struct arvore* raiz, struct arvore* filho, int valor)
{
	if(filho == NULL)	
	{
		filho = (struct arvore*)malloc(sizeof(struct arvore));
		if (filho == NULL) 
		{
			printf("\nErro alocando memoria.");
			exit(0);
		}
		filho->esquerda = NULL;
		filho->direita = NULL;
		filho->valor = valor;
		if(raiz == NULL) return filho; 
		if(valor < raiz->valor) raiz->esquerda = filho;
		else raiz->direita = filho;
		return filho;		
	}
	if (valor < filho->valor) sarvore(filho, filho->esquerda, valor);
	else sarvore(filho, filho->direita, valor);
}

struct arvore* darvore(struct arvore* raiz, int valor)
{
	struct arvore *p, *p2;
	if(raiz == NULL) return raiz;	
	if(raiz->valor == valor)
	{
		if(raiz->esquerda == raiz->direita)
		{
			free(raiz);	return NULL;	
		} else if (raiz->esquerda == NULL)
		{
			p = raiz->direita; free(raiz); return p;	
		}
		else if (raiz->direita == NULL)
		{
			p = raiz->esquerda; free(raiz); return p;
		}
		else
		{
			p2 = raiz->direita;	p = raiz->direita;
			while(p->esquerda) p = p->esquerda;
			p->esquerda = raiz->esquerda;
			free(raiz);	return p2;
		}
	}
	if (raiz->valor < valor) raiz->direita = darvore(raiz->direita, valor);
	else raiz->esquerda = darvore(raiz->esquerda, valor);
	return raiz;
}

void pesquisar(struct arvore* raiz, int valor)
{
	struct arvore* aux;
	aux = raiz;
	if (aux == NULL) printf("\nValor nao encontrado.");
	else
	{	
	  while(aux->valor != valor)
	  {
		if (valor < aux->valor) aux = aux->esquerda;
		else aux = aux->direita;
		if (aux == NULL) break;
	  }	
	  if (aux != NULL) printf("\nValor encontado."); 
	  else printf("\nValor nao encontrado.");
	}
}

void imprimirOrdenado(struct arvore* raiz)
{
	if (raiz == NULL) return;
	imprimirOrdenado(raiz->esquerda);
	if (raiz->valor != NULL) printf("%d ", raiz->valor);
	imprimirOrdenado(raiz->direita);
}

void imprimirPreOrdenado(struct arvore* raiz)
{
	if (raiz == NULL) return;
	if (raiz->valor != NULL) printf("%d ", raiz->valor);
	imprimirPreOrdenado(raiz->esquerda);	
	imprimirPreOrdenado(raiz->direita);
}

void imprimirPosOrdenado(struct arvore* raiz)
{	
	if (raiz == NULL) return;
	imprimirPosOrdenado(raiz->esquerda);	
	imprimirPosOrdenado(raiz->direita);
	if (raiz->valor != NULL) printf("%d ", raiz->valor);
}

int main(int argc, char** argv) {
	int num, opcao;
	struct arvore* raiz;
	do
	{
		printf("\n");
		printf(" 1 - Iniciar arvore\n");
		printf(" 2 - Incluir no\n");			
		printf(" 3 - Pesquisar no\n");			
		printf(" 4 - Excluir no\n");			
		printf(" 5 - Impressao ordenada\n");			
		printf(" 6 - Impressao pr�-ordenada\n");			
		printf(" 7 - Impressao p�s-ordenada\n");			
		printf("0 - SAIR\n");
		printf("\nEntre com a opcao: "); 
		scanf("%d", &opcao);
		switch (opcao)
		{
			case 1: 
				raiz = NULL;
				printf("\nArvore iniciada.");
				break;	
			case 2:		
				printf ("\nEntre com o numero para o novo no: "); 
				scanf ("%d", &num);				
				if (raiz == NULL) raiz = sarvore(raiz, raiz, num); 
				else sarvore(raiz, raiz, num);				
				break;				
			case 3:
				printf ("\nEntre com o numero para pesquisa: "); 
				scanf ("%d", &num);				
				pesquisar(raiz, num);
				break;
			case 4:
				printf ("\nEntre com o numero para excluir: "); 
				scanf ("%d", &num);				
				raiz = darvore(raiz, num);
				break;
			case 5:
				imprimirOrdenado(raiz);
				break;			
			case 6:
				imprimirPreOrdenado(raiz);
				break;			
			case 7:
				imprimirPosOrdenado(raiz);
				break;		
		}
		fflush(stdin);
	} while (opcao != 0); 
	return 0;
}
