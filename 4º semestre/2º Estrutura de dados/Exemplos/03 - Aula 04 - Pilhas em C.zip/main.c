#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
#define TAM 10

typedef struct 
{
	int topo;
	int valores[TAM];
} sPilha;

void inicialize(sPilha* pilha)
{
	pilha->topo = -1;
	printf("\nPilha inicializada");
}

int full(sPilha* pilha)
{
	return pilha->topo == (TAM - 1);
}

int empty(sPilha* pilha)
{
	return 	pilha->topo == -1;
}

void push(sPilha* pilha, int valor) //inclui
{
	if (full(pilha))
	{
		printf ("\nPilha cheia");		
	}
	else
	{
		pilha->topo = pilha->topo + 1;
		pilha->valores[pilha->topo] = valor;
	}	
}

int pop(sPilha* pilha) //retira
{
	int num;
	if (empty(pilha))
	{
		printf ("\nPilha esta vazia.");	
		num = pilha->topo;					
	}
	else
	{
		num = pilha->valores[pilha->topo];		
		pilha->topo = pilha->topo - 1;		
	}	
	return num;
}

int stacktop(sPilha* pilha)
{
	int num;
	if (empty(pilha))
	{
		printf ("\nPilha esta vazia.");	
		num = pilha->topo;					
	}
	else
	{
		num = pilha->valores[pilha->topo];				
	}	
	return num;
}

void print(sPilha* pilha)
{
	int i;
	if (empty(pilha)) printf ("\nPilha esta vazia.");	
	else
	{
		for(i = pilha->topo; i >= 0; i--)
		{
			printf("\nPilha posicao %d com valor %d .", i, pilha->valores[i]);
		}
	}	
}

int main(int argc, char *argv[]) {
	sPilha pilha; int opcao, num;
	do
	{
		printf("\n");
		printf("1 - Inicializa\n");	
		printf("2 - POP\n");
		printf("3 - PUSH\n");
		printf("4 - STACKTOP\n");
		printf("5 - PRINT\n");
		printf("0 - SAIR\n");
		printf("\nEntre com a opcao: "); scanf("%d", &opcao);
		switch (opcao)
		{
			case 1: inicialize(&pilha);
				break;
			case 2:	printf("\nNumero desempilhado %d", pop(&pilha));
				break;				
			case 3:	
				printf ("\nEntre com o numero para empilhar: "); scanf ("%d", &num);
				push(&pilha, num);
				break;
			case 4:	
				printf("\nNumero no topo %d", stacktop(&pilha));
				break;
			case 5:
				print(&pilha);
				break;
		}
		fflush(stdin);
	} while (opcao != 0);		
	return 0;
}


