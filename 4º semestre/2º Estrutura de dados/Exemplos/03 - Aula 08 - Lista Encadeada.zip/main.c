#include <stdio.h>
#include <stdlib.h>

typedef struct no {
  int info;
  struct no* next;
} sLista, sNo; 
//sLista ou sNo equivale a 
//chamar struct no

sNo* criarNo(int valor)
{
  sNo* p = (sNo*)malloc(sizeof(sNo));
  p->info = valor;
  p->next = NULL;
  return p;
}

sLista* inicializaLista()
{
	printf("\nLista criada.");
	return NULL;
}

sLista* inserirInicio(sNo* no, int valor)
{
  sNo* novo = criarNo(valor);
  novo->next = no;
  return novo;
}


void imprimirLista(sLista* lista)
{
  sNo* p; 
  for (p = lista; p != NULL; p = p->next) 
    printf("info = %d\n", p->info);
}

sNo* buscarNo(sLista* lista, int valor)
{
  sNo* p;
  for (p=lista; p!=NULL; p=p->next)
  if (p->info == valor) return p;
  return NULL; 
}

sLista* excluirNo(sLista* lista, int valor) 
{
  sNo* ant = NULL; /* ponteiro para elemento anterior */
  sNo* p = lista;  /* ponteiro para percorrer a lista*/  
  while (p != NULL && p->info != valor) { /* procura elemento na lista, guardando anterior */
    ant = p;
    p = p->next;
  }
  /* verifica se achou elemento */
  if (p == NULL) return lista; /* n�o achou: retorna lista original */  
  if (ant == NULL) {
    /* retira elemento do inicio */
   lista = p->next;
  }
  else 
  {
    /* retira elemento do meio da lista */
    ant->next = p->next;
  }
  free(p);
  return lista;
}


sLista* liberarLista(sLista* lista)
{
  sNo* p = lista;
  while (p != NULL) {
    sNo* t = p->next; /* guarda refer�ncia para o pr�ximo elemento */
    free(p); /* libera a mem�ria apontada por p */
    p = t; /* faz p apontar para o pr�ximo */
  }
  return p;
}

sLista* insereOrdenado(sLista* lista, int valor)
{
  sNo* novo = criarNo(valor); /* cria novo n� */
  sNo* ant = NULL; /* ponteiro para elemento anterior */
  sNo* p = lista; /* ponteiro para percorrer a lista*/
  /* procura posi��o de inser��o */
  while (p != NULL && p->info < valor) {
    ant = p;
    p = p->next;
  }
  /* insere elemento */
  if (ant == NULL) { /* insere elemento no in�cio */
    novo->next = lista;
    lista = novo;
  }
  else { /* insere elemento no meio da lista */
    novo->next = ant->next;
    ant->next = novo;
  }
  return lista;
}

void alterar(sLista* lista, int valor, int novo)
{	
   sLista* p;
   int achou = 0;   	
   p = lista;
   while (p != NULL)
   {  
   	  if (p->info == valor)
      {  
	    p->info = novo;
	    achou = 1;
	    break;
      }
	  p = p->next;
   }
   if (achou == 1)
      printf("\nO valor %d foi alterado para %d!\n", valor, novo);
   else
      printf("\nNao foi possivel a alteracao: O valor nao existe na lista.\n");
}

sLista* inserirFinal(sLista* lista, int valor)
{
  sLista* p = lista; 
  if (lista == NULL) return inserirInicio(lista, valor);		
  else
  {
  	while(p->next != NULL) p = p->next;  	  	
  	p->next = criarNo(valor);
    return lista;      	
  }  
}

int tamanho(sLista* lista)
{
    int cont = 0; sNo* p = lista;
    while (p != NULL)
    {
        p = p->next;
        cont++;
    }
    return cont;
}

int main(int argc, char *argv[]) {
		
	sLista* lista; sNo* no;
	int opcao, num, novo;
	do
	{
		printf("\n");
		printf("1 - Iniciar lista\n");			
		printf("2 - Inserir inicio\n");
		printf("3 - Remover no\n");
		printf("4 - Imprimir lista\n");
		printf("5 - Buscar no\n");
		printf("6 - Liberar lista\n");
		printf("7 - Inserir ordenado\n");
		printf("8 - Alterar no\n");
		printf("9 - Inserir fim\n");
		printf("10 - Tamanho da lista\n");
		printf("0 - SAIR\n");
		printf("\nEntre com a opcao: "); 
		scanf("%d", &opcao);
		switch (opcao)
		{
			case 1: 
				lista = inicializaLista();
				break;
			case 2:	
				printf ("\nEntre com o numero para o novo no: "); 
				scanf ("%d", &num);
				lista = inserirInicio(lista, num);
				break;				
			case 3:	
				printf ("\nEntre com o numero para remover: "); 
				scanf ("%d", &num);
				lista = excluirNo(lista, num);
				break;			
			case 4:	
				imprimirLista(lista);
				break;		
			case 5:
				printf ("\nEntre com o numero para pesquisa: "); scanf ("%d", &num);
				no = buscarNo(lista, num);
				if (no == NULL) printf("\nValor n�o encontrado.");
				else printf("\nValor encontrado.");
				break;	
			case 6:
				lista = liberarLista(lista);
				printf("\nLista liberada.");
				break;
			case 7:
				printf ("\nEntre com o numero para o novo no: "); scanf ("%d", &num);
				lista = insereOrdenado(lista, num);
				break;
			case 8:
				printf ("\nEntre com o valor a alterar: "); scanf ("%d", &num);
				printf ("\nEntre com o novo valor: "); scanf ("%d", &novo);
				alterar(lista, num, novo);
				break;
			case 9:
				printf ("\nEntre com o numero para o novo no: "); scanf ("%d", &num);
				lista = inserirFinal(lista, num);
				break;
			case 10:
				printf("\nO tamanho da lista eh de %d nos.\n", tamanho(lista));
				break;
		}
		fflush(stdin);
	} while (opcao != 0);	
	return 0;
}
