#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

typedef struct no {
  int info;
  struct no* next;
} sPilha, sNo; 

sNo* criarNo(int valor)
{
  sNo* p = (sNo*)malloc(sizeof(sNo));
  p->info = valor;
  p->next = NULL;
  return p;
}

sPilha* inicialize()
{
	printf("\nPilha inicializada\n");
	return NULL;
}

int empty(sPilha* pilha)
{
	return pilha == NULL;	
}

sPilha* push(sPilha* pilha, int valor) //inclui, empilha
{
	sNo* p = criarNo(valor);
	p->next = pilha;
	return p;
}

int pop(sPilha** pilha) //retira, desempilha
{
	int num; sNo* p;
	if (empty(*pilha))
	{	
		printf ("\nPilha esta vazia.");	
		num = *pilha;		
	}
	else
	{
		p = (*pilha);
		num = p->info;				
		*pilha = p->next;
		free(p);
	}		
	return num;
}

int stacktop(sPilha* pilha)
{
	int num;
	if (empty(pilha))
	{
		printf ("\nPilha esta vazia.");	
		num = pilha;					
	}
	else
	{
		num = pilha->info;
	}	
	return num;
}

void print(sPilha* pilha)
{
	sNo* p; 
	if (empty(pilha)) 
	printf ("\nPilha esta vazia.");	
	else	
		for (p = pilha; p != NULL; p = p->next) 
			printf("\nInfo = %d", p->info);
}

int main(int argc, char *argv[]) {
	sPilha* pilha; int opcao, num;
	do
	{
		printf("\n");
		printf("1 - Inicializa\n");	
		printf("2 - POP\n");
		printf("3 - PUSH\n");
		printf("4 - STACKTOP\n");
		printf("5 - PRINT\n");
		printf("0 - SAIR\n");
		printf("\nEntre com a opcao: "); scanf("%d", &opcao); 
		switch (opcao)
		{
			case 1: 
			    pilha = inicialize();
				break;
			case 2:					
				printf("\nNumero desempilhado %d", pop(&pilha)); printf("\n");
				break;				
			case 3:	
				printf ("\nEntre com o numero para empilhar: "); scanf ("%d", &num); printf("\n");
				pilha = push(pilha, num);
				break;
			case 4:	
				printf("\nNumero no topo %d", stacktop(pilha)); printf("\n");
				break;
			case 5:
				print(pilha); printf("\n");
				break;
		}
		fflush(stdin);
	} while (opcao != 0);		
	return 0;
}


