#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#define MAX 100

typedef struct flight
{
	char from[20]; 
	char to[20]; 
	int distance;
	char skip; 
};

struct flight flights[MAX];
int lastposition = 0; 

typedef struct stack
{
	char from[20];
	char to[20];
	int dist;
};

struct stack bt_stack[MAX]; //pilha de retorno
struct stack solution[MAX]; //guarda solucoes temporarias

int tos = 0; //topo da pilha de retorno
int stos = 0; //topo da pilha de solucoes

void setup() //cadastra os voos
{
	assert_flight("New York", "Chicago", 1000);
	assert_flight("Chicago", "Denver", 1000);
	assert_flight("New York", "Toronto", 800);
	assert_flight("New York", "Denver", 1900);
	assert_flight("Toronto", "Calgary", 1500);
	assert_flight("Toronto", "Los Angeles", 1800);
	assert_flight("Toronto", "Chicago", 500);
	assert_flight("Denver", "Urbana", 1000);
	assert_flight("Denver", "Houston", 1500);
	assert_flight("Houston", "Los Angeles", 1500);
	assert_flight("Denver", "Los Angeles", 1000);
}

void assert_flight(char* from, char* to, int dist) //cadastra o voo
{
	if (lastposition < MAX)
	{
		strcpy(flights[lastposition].from, from);
		strcpy(flights[lastposition].to, to);
		flights[lastposition].distance = dist;
		flights[lastposition].skip = 0;
		lastposition++;
		printf("Rota cadstrada: %s %s \n", from, to);
	} else printf("Banco de dados de v�os est� cheio.\n");
}

int match(char* from, char* to) //verifica se existe voo entre from e to e devolve a distancia
{
	int t;
	for(t = lastposition - 1; t > -1; t--)	
	{
		if(!strcmp(flights[t].from, from) && !strcmp(flights[t].to, to)) 
			return flights[t].distance;
	}
	return 0;
}

int find(char* from, char* anywhere) //pesquisa origem para destino
{
	int findpos = 0;
	while(findpos < lastposition)
	{
		if(!strcmp(flights[findpos].from, from) && !flights[findpos].skip)
		{
			strcpy(anywhere, flights[findpos].to);
			flights[findpos].skip = 1; //torna ativo
			return flights[findpos].distance;
		}
		findpos++;
	}	
	return 0;
}

void push(char* from, char* to, int dist)
{
	if (tos < MAX)
	{
		strcpy(bt_stack[tos].from, from);
		strcpy(bt_stack[tos].to, to);
		bt_stack[tos].dist = dist;
		tos++;
	} else printf("Pilha cheia.\n");
}

void pop(char* from, char* to, int* dist)
{
	if(tos > 0)
	{
		tos--;
		strcpy(from, bt_stack[tos].from);
		strcpy(to, bt_stack[tos].to);
		*dist = bt_stack[tos].dist;
	} else printf("Pilha vazia.\n");
}

void isflight(char* from, char* to) //determina se h� uma rota entre from e to (origem e destino)
{
	int d, dist;
	
	char anywhere[20];
	//ve se esta no destino
	if(d = match(from, to))
	{
		push(from, to, d);		
		return;
	}
	//tenta outra conexao
	if(dist = find(from, anywhere))
	{
		push(from, to, dist);
		isflight(anywhere, to);
	}
	else if(tos > 0) //retorna
	{
		pop(from, to, &dist);
		isflight(from, to);		
	}		
}

void route(char* to) //mostra a rota e a distancia total
{
	int dist, t;
	dist = 0;
	t = 0;
	while(t < tos)
	{
		printf("%s para ", bt_stack[t].from);
		dist += bt_stack[t].dist;
		t++;
	}
	printf("%s\n", to);
	printf("Distancia total de %d milhas.\n", dist);
}

int main(int argc, char *argv[]) {		
	char from[20], to[20];
	setup();
	printf("De?");
	gets(from);
	printf("Para?");
	gets(to);
	isflight(from, to);
	route(to);
	system("pause");
	return 0;
}

