#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

typedef struct no
{
	int info;
	struct no* anterior;
	struct no* proximo;
} sLista, sNo;

sLista* inicializaLista()
{
	printf("\nLista criada");
	return NULL;
}

sNo* criarNo(int valor, sNo* anterior, sNo* proximo)
{
	sNo* p  = (sNo*)malloc(sizeof(sNo));	
	p->info = valor;
	p->anterior = anterior;
	p->proximo = proximo;
	return p;
}

sLista* inserirInicio(sNo* no, int valor)
{
	sNo* novo = criarNo(valor, NULL, no);
	if (no != NULL) no->anterior = novo;	
	return novo;	
}

sLista* inserirFinal(sLista* lista, int valor)
{
	sLista* p = lista;
	if (lista == NULL) return inserirInicio(lista, valor);	
	else
	{
		while(p->proximo != NULL) p = p->proximo;
		p->proximo = criarNo(valor, p, NULL);
		return lista;
	}		
}

sLista* inserirOrdenado(sLista* lista, int valor)
{
	sNo* p = lista;
	if (p == NULL) lista = inserirInicio(lista, valor);
	else
	{
		while(p != NULL && p->info < valor) p = p->proximo;
		if (p == NULL) lista = inserirFinal(lista, valor);
		else
		{
			if(p->anterior == NULL) lista = inserirInicio(lista, valor);
			else
			{
				sNo* novo = criarNo(valor, p->anterior, p->proximo);
				p->anterior->proximo = novo;
				p->anterior = novo;
			}
		}
	}
	return lista;
}

sLista* excluirNo(sLista* lista, int valor)
{
	sNo* p = lista;
	while(p != NULL && p->info != valor) p = p->proximo;
	if (p == NULL) printf("\nValor nao encontrado.");
	else
	{
		if (p->anterior == NULL)
		{
			p->proximo->anterior = NULL;
			lista = p->proximo;
		}
		else
		{
			if(p->proximo == NULL) p->anterior->proximo = NULL;
			else
			{
				p->anterior->proximo = p->proximo;
				p->proximo->anterior = p->anterior;
			}
		}
		free(p);
		printf("\nValor excluido");
	}
	return lista;
}

int main(int argc, char *argv[]) {
	sLista* lista;
	int opcao, num;
	do
	{
		printf("\n");	
		printf("1 - Iniciar Lista\n");
		printf("2 - Inserir inicio\n");
		printf("3 - Inserir final\n");
		printf("4 - Inserir ordenado\n");
		printf("5 - Excluir\n");
		printf("0 - Sair\n\n");
		printf("Entre com a opcao: \n");
		scanf("%d", &opcao);
		switch(opcao)
		{
			case 1:
				lista = inicializaLista();
				break;				
			case 2:
				printf("\nEntre com o numero para o novo no: ");
				scanf("%d", num);
				lista = inserirInicio(lista, num);
				break;
			case 3:
				printf("\nEntre com o numero para o novo no: ");
				scanf("%d", num);
				lista = inserirFinal(lista, num);
				break;
			case 4:
				printf("\nEntre com o numero para o novo no: ");
				scanf("%d", num);
				lista = inserirOrdenado(lista, num);
				break;	
			case 5:
				printf("\nEntre com o numero para excluir: ");
				scanf("%d", num);
				lista = excluirNo(lista, num);
				break;	
		}
		fflush(stdin);
	} while (opcao != 0);
	
	return 0;
}
