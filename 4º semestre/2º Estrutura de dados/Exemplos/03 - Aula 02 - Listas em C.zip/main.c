#include <stdio.h>
#include <stdlib.h>

#define TOTAL 10

typedef struct cliente
{
	char nome[30];
	int  idade;
} sCliente;

typedef struct lista
{
	sCliente vetor[TOTAL];
	int nElemento;
} sLista;

void criarLista(sLista* lista)
{
	lista->nElemento = 0;
	printf("Lista criada.\n");
}

void excluirLista(sLista* lista)
{
	lista->nElemento = 0;
	printf("Lista excluida.\n");
}

int tamanho(sLista* lista)
{
	return lista->nElemento;
}

void inserirFim(sLista* lista, sCliente cliente)
{
	lista->vetor[lista->nElemento] = cliente;
	lista->nElemento = lista->nElemento + 1;
}

void inserirPosicao(sLista* lista, int posicao, sCliente cliente)
{
	int i;
	if (posicao >= lista->nElemento) inserirFim(lista, cliente);
	else
	{
		for(i = lista->nElemento; i > posicao; i--) lista->vetor[i] = lista->vetor[i - 1];
		lista->vetor[posicao] = cliente;
		lista->nElemento = lista->nElemento + 1;	
	}
}

void inserirInicio(sLista* lista, sCliente cliente)
{
	inserirPosicao(lista, 0, cliente);
}

void excluirPosicao(sLista* lista, int posicao)
{
	int i;
	if (posicao < lista->nElemento)
	{
		if (posicao == lista->nElemento - 1) lista->nElemento = lista->nElemento - 1;
		else
		{
			for(i = posicao; i < lista->nElemento - 1; i++) lista->vetor[i] = lista->vetor[i + 1];
			lista->nElemento = lista->nElemento - 1;
		}
	}
}

int main(int argc, char *argv[]) {
	int opcao, posicao; sLista lista; sCliente cliente;
	do
	{
		printf("\n");	
		printf("1 - Criar lista\n");	
		printf("2 - Inserir inicio\n");	
		printf("3 - Inserir final\n");
		printf("4 - Inserir posicao\n");
		printf("5 - Tamanho da lista\n");
		printf("6 - Excluir posicao\n");
		printf("7 - Excluir lista\n");
		printf("8 - Imprimir lista\n");
		printf("0 - Sair\n");
		printf("Digite a opcao:"); scanf("%d", &opcao); 
		
		switch(opcao)
		{
			case 1: criarLista(&lista);
				break;
			case 2: 
				printf("\nInforme o nome: "); scanf("%s", &cliente.nome);
				printf("\nInforme a idade: "); scanf("%d", &cliente.idade);
				inserirInicio(&lista, cliente);
				break;
			case 3:
				printf("\nInforme o nome: "); scanf("%s", &cliente.nome);
				printf("\nInforme a idade: "); scanf("%d", &cliente.idade);
				inserirFim(&lista, cliente);
				break;
			case 4:
				printf("\nInforme o nome: "); scanf("%s", &cliente.nome);
				printf("\nInforme a idade: "); scanf("%d", &cliente.idade);
				printf("\nInforme a posicao: "); scanf("%d", &posicao);
				inserirPosicao(&lista, posicao, cliente);
				break;	
			case 5:
				printf("\nTamanho da lista: %d \n", tamanho(&lista));
				break;
			case 6:
				printf("\nInforme a posicao: "); scanf("%d", &posicao);				
				excluirPosicao(&lista, posicao);
				break;
			case 7:
				excluirLista(&lista);
				break;
			case 8:
				break;
			default:
				printf("\nOpcao invalida.");
				break;
		}
		
	} while(opcao != 0);
	printf("\nFim do Programa");
	return 0;
}
